export { default as branch_data} from './branch_data.json'
